=== Feed Plus ===
Contributors: Eric-Oliver M�chler v/o Annubis
Donate link: http://www.annu.biz
Tags: feed, editor, banner, code
Version: 1.0.1
Requires at least: 2.7+
Tested up to: 3.1
Stable tag: 1.0
Plugin URL: http://www.annu.biz/wordpress-plugin-feed-plus/



== Description ==
Mit Feed Plus ist man in der Lage Werbung, Infos und andere wichtige Dinge direkt im Feed zu publizieren.

WICHTIG: Dieses Plugin befindet sich noch in der Entwicklung. Obwohl das Plugin, vor der ver�ffentlichung,
bereits getestet wurde, k�nnten Probleme mit deinem Bestehenden Blog auftreten. Jegliche Haftung wird abgelehnt.
Das Ben�tzen dieses Plugins beruht auf eigene Gefahr.

== Installation ==
1. Upload des Plugins in den Plugin-Ordner /wp-content/plugins/
2. In der Plugin-Administration ihres Blogs kann nun Feed Plus aktiviert werden.
3. Feed Plus nun in der Feed Plus Administration konfigurieren.
4. Ein Beitrag schreiben und ver�ffentlichen und dann das Ergebniss bewundern.


= Licence =
Good news, this plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal. If you will using this Plugin on a commercial blog - its also free of charge but please send me an email (plugins@annu.biz) and inform me.


== Screenshots ==
No Screenshots aviable yet

== Frequently Asked Questions ==
Frage:        Wie merke ich, ob es eine neue Version des Plugins gibt?
Antwort:         Dann wird man im Plugin Ordner deiner WP Installation auf die Upgrade-M�glichkeit aufmerksam gemacht.

Frage:        Was muss ich tun, wenn ich ein Bug bemerke?
Antwort:         Man schickt dem Entwickler eine eMail an plugins@annu.biz und meldet den Bug und wie man ihn nachvollziehen kann.

== Upgrade Notice ==


== Changelog ==
= v1.0 (02/05/2011) =
* upgrade to v1.0
* add in the official wordpress plugin download sektion

= v0.9 (12/26/2008) =
* first releasing